package org.bouncycastle.tls;

/**
 * RFC 2246
 * <p>
 * Note that the values here are implementation-specific and arbitrary. It is recommended not to
 * depend on the particular values (e.g. serialization).
 */
public class ConnectionEnd
{
    public static final int server = 0;
    public static final int client = 1;
}
